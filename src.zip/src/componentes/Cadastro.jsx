import React from "react";
import { useNavigate } from "react-router-dom";
import "./Cadastro.css";

export default function Cadastro() {
  const navigate = useNavigate();

  return (
  <>

  <section className="PaginaCadastro">
        <header>
            <h1 className="titulo">INTEGRA</h1>
            <p className="subtitulo">Portal do Aluno & Docente</p>
            <div className="iconIntegra"></div>

        </header>

<section className="cadastro">
  <h1 className="tituloCadastreSe">Cadastre-se:</h1>
      <div className="container">
       

        {/* ALUNO */}
        <div className="box">
          <div className="boxTopo">
            {/* <div className="icon"><img src="" alt="" /></div> */}
            <h2 className="tituloBox">Aluno</h2>
            <p className="subtituloBox">
              Inicie seu percurso acadêmico no Integra.
            </p>
          </div>
          
          <div className="boxBaixo">
          <div className="inputs">
            <div className="tituloInput">Nome Completo</div>
            {/* <div className="icon"><img src="" alt="" /></div> */}
            <input
              type="text"
              placeholder="Ex: Bianca Silva Santos"
              className="nome"
            />  
          </div>
          <div className="inputs">
            <div className="tituloInput">E-mail Institucional</div>
            {/* <div className="icon"><img src="" alt="" /></div> */}
            <input
              type="text"
              placeholder="nome.sobrenome@aluno.senai.br"
              className="email"
            />
          </div>
          <div className="inputs">
            <div className="tituloInput">Senha</div>
            {/* <div className="icon"><img src="" alt="" /></div> */}
            <input type="password" placeholder="12345" className="senha" />
          </div>
          <div className="inputs">
            <div className="tituloInput">Turma</div>
            {/* <div className="icon"><img src="" alt="" /></div> */}
            <option value="">Selecione sua turma</option>
          </div>
          
          <button className="botaoCadastro">Cadastrar como Aluno →</button>
        </div>
        </div>

        {/* DOCENTE */}
        <div className="box">
          <div className="boxTopo">
            {/* <div className="icon"><img src="" alt="" /></div> */}
            <h2 className="tituloBox">Docente</h2>
            <p className="subtituloBox">
              Acesso administrativo e pedagógico para professores.
            </p>
          </div>

          <div className="boxBaixo">
          <div className="inputs">
            <div className="tituloInput">Nome Completo</div>
            {/* <div className="icon"><img src="" alt="" /></div> */}
            <input
              type="text"
              placeholder="Ex: Prof. Emerson Rodriguez"
              className="nome"
            />
          </div>
          <div className="inputs">
            <div className="tituloInput">E-mail Corporativo (@senai)</div>
            {/* <div className="icon"><img src="" alt="" /></div> */}
            <input
              type="text"
              placeholder="nome.sobrenome@senai.br"
              className="email"
            />
          </div>
          <div className="inputs">
            <div className="tituloInput">Senha</div>
            {/* <div className="icon"><img src="" alt="" /></div> */}
            <input
              type="password"
              placeholder="12345"
              className="senha"
            />
          </div>
          <div className="inputs">
            <div className="tituloInput">Unidade Senai</div>
            {/* <div className="icon"><img src="" alt="" /></div> */}
            <option value=""></option>
          </div>
          <div className="inputs">
            <div className="tituloInput">Dicipina Principal</div>
            {/* <div className="icon"><img src="" alt="" /></div> */}
            <input type="text" placeholder="Ex: História" className="diciplina" />
          </div>
          <button className="botaoCadastro">Cadastrar como Docente →</button>
        </div>
        </div>
        </div>

        <footer>
            Já possui uma conta?{" "}
            <span onClick={() => navigate("/login")}>Fazer Login</span>
          </footer>
    </section>
    </section>
  </>
  );
}
