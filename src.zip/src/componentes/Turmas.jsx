import "./Turmas.css";
import { Link, useParams } from "react-router-dom";
import NavbarDocente from "./NavbarDocente";

const materias = [
	{ slug: "portugues", nome: "Português", foco: "linguística e interpretação textual" },
	{ slug: "matematica", nome: "Matemática", foco: "raciocínio lógico e resolução de problemas" },
	{ slug: "geografia", nome: "Geografia", foco: "análise espacial e compreensão do território" },
	{ slug: "biologia", nome: "Biologia", foco: "processos biológicos e ciências da vida" },
	{ slug: "quimica", nome: "Química", foco: "transformações químicas e análise de materiais" },
	{ slug: "fisica", nome: "Física", foco: "fenômenos físicos e aplicação de conceitos" },
	{ slug: "ingles", nome: "Inglês", foco: "comunicação e interpretação em língua inglesa" },
	{ slug: "historia", nome: "História", foco: "análise histórica e compreensão de contextos" },
];

const alunosDemonstracao = [
	{ id: 1, nome: "Lucas Oliveira", indicador: "Média atual", valor: "4.2", alerta: "Dificuldade Crítica: Interpretação", nivel: "critico", progresso: 42 },
	{ id: 2, nome: "Ana Souza", indicador: "Frequência", valor: "72%", alerta: "Queda de Frequência Recente", nivel: "atencao", progresso: 72 },
	{ id: 3, nome: "Mateus Lima", indicador: "Última nota", valor: "5.8", alerta: "Alerta de Rendimento", nivel: "monitorar", progresso: 58 },
];

const dadosDemonstracao = Object.fromEntries(materias.map((materia) => [materia.slug, {
	materia: materia.nome,
	professor: { nome: "Ricardo Silva", unidade: "Unidade Senai Centro" },
	turma: "Turma 3B",
	resumo: `Monitoramento pedagógico centralizado para análise de desempenho em ${materia.foco}.`,
	alerta: {
		titulo: "Atenção: Alto índice de reprovação detectado",
		descricao: "Nossos algoritmos identificaram um padrão de queda acentuada na turma. O aluno Lucas está apresentando dificuldades severas, o que pode impactar transversalmente outras disciplinas. Recomenda-se intervenção pedagógica imediata.",
		severidade: "Alerta Crítico",
	},
	alunosRisco: alunosDemonstracao,
	metricas: {
		mediaTurma: "7.8",
		variacaoMedia: "+0.5 vs. mês ant.",
		aulasMinistradas: 24,
		aulasTotais: 40,
		atividadesPendentes: 2,
		alunosCriticos: 3,
	},
}]));

function iniciais(nome) {
	return nome.split(" ").slice(0, 2).map((parte) => parte[0]).join("").toUpperCase();
}

export default function Turmas({ dadosPorMateria = dadosDemonstracao }) {
	const { materia: materiaDaRota } = useParams();
	const chaveMateria = materiaDaRota || "portugues";
	const materiaEncontrada = materias.find((item) => item.slug === chaveMateria);
	const dados = dadosPorMateria[chaveMateria] || dadosPorMateria.portugues;
	const nomeMateria = dados.materia || materiaEncontrada?.nome || "Português";
	const alunosRisco = dados.alunosRisco || [];
	const metricas = dados.metricas || {};
	const descricaoAlerta = dados.alerta?.descricao || "Não há detalhes de alerta disponíveis para esta matéria.";

	return (
		<div className="turmas-pagina">
			<NavbarDocente ativa="turmas" nomeProfessor={dados.professor?.nome || "Ricardo Silva"} />

			<div className="turmas-layout">
				<aside className="turmas-sidebar">
					<div className="turmas-perfil-docente">
						<span className="turmas-icone-perfil" aria-hidden="true"></span>
						<div>
							<strong>{dados.professor?.nome || "Nome do Professor"}</strong>
							<span>{dados.professor?.unidade || "Unidade de ensino"}</span>
						</div>
					</div>
					<nav className="turmas-menu-lateral" aria-label="Menu do docente">
						<Link to="/portal-docente"><span aria-hidden="true">▦</span> Visão Geral</Link>
						<Link className="turmas-menu-ativa" to="/turmas"><span aria-hidden="true">▣</span> Minhas Disciplinas</Link>
						<a href="#alerta-materia"><span aria-hidden="true">◉</span> Alertas IA</a>
						<a href="#metricas-materia"><span aria-hidden="true">▤</span> Relatórios</a>
						<a href="#privacidade"><span aria-hidden="true">⬡</span> LGPD</a>
					</nav>
					<button className="turmas-nova-anotacao" type="button" onClick={() => document.getElementById("nova-anotacao")?.focus()}>
						+ Nova Anotação
					</button>
				</aside>

				<main className="turmas-conteudo">
					<section className="turmas-cabecalho-materia" aria-labelledby="turmas-titulo">
						<div className="turmas-titulo-materia">
							<span>▤ Currículo Base</span>
							<h1 id="turmas-titulo">Disciplina: {nomeMateria} - Visão Geral</h1>
							<p>{dados.resumo || `Acompanhamento pedagógico da disciplina de ${nomeMateria}.`}</p>
						</div>
						<div className="turmas-acoes-materia">
							<a className="turmas-botao-secundario" href="#alunos-risco"><span aria-hidden="true"></span> Ver Todos os Alunos</a>
							<a className="turmas-botao-principal" href="#metricas-materia"><span aria-hidden="true">▣</span> Visão Geral por Matéria</a>
						</div>
					</section>

					<section className="turmas-alerta" id="alerta-materia" aria-labelledby="turmas-alerta-titulo">
						<div className="turmas-alerta-simbolo" aria-hidden="true"></div>
						<div className="turmas-alerta-conteudo">
							<div className="turmas-alerta-etiquetas">
								<span>Análise preditiva</span>
								<strong>• {dados.alerta?.severidade || "Alerta"}</strong>
							</div>
							<h2 id="turmas-alerta-titulo">{dados.alerta?.titulo || "Acompanhamento da turma"}</h2>
							<p>{descricaoAlerta}</p>
						</div>
						<div className="turmas-alerta-acoes">
							<a href="#alunos-risco">Abrir Plano de Ação</a>
							<span>Ignorar alerta por 24h</span>
						</div>
					</section>

					<section className="turmas-alunos-risco" id="alunos-risco" aria-labelledby="alunos-risco-titulo">
						<div className="turmas-risco-cabecalho">
							<h2 id="alunos-risco-titulo"><span aria-hidden="true">▲</span> Alunos em Risco</h2>
							<span>{alunosRisco.length} alertas ativos hoje</span>
						</div>
						{alunosRisco.length ? (
							<div className="turmas-grade-alunos">
								{alunosRisco.map((aluno) => (
									<article className={`turmas-card-aluno turmas-aluno-${aluno.nivel || "atencao"}`} key={aluno.id ?? aluno.nome}>
										<div className="turmas-aluno-topo">
											<div className="turmas-avatar-aluno" aria-hidden="true">{aluno.foto ? <img src={aluno.foto} alt="" /> : iniciais(aluno.nome)}</div>
											<span className="turmas-nivel-aluno">{aluno.rotulo || (aluno.nivel === "critico" ? "Crítico" : aluno.nivel === "monitorar" ? "Monitorar" : "Atenção")}</span>
										</div>
										<h3>{aluno.nome}</h3>
										<p className="turmas-indicador-aluno">{aluno.indicador || "Indicador"}: <strong>{aluno.valor || "-"}</strong></p>
										<p className="turmas-alerta-aluno"><span aria-hidden="true">◉</span> {aluno.alerta || "Necessita acompanhamento"}</p>
										<div className="turmas-barra-aluno" role="progressbar" aria-label={`Indicador de risco de ${aluno.nome}`} aria-valuenow={aluno.progresso ?? 0} aria-valuemin="0" aria-valuemax="100">
											<span style={{ width: `${Math.min(100, Math.max(0, aluno.progresso ?? 0))}%` }} />
										</div>
									</article>
								))}
							</div>
						) : (
							<p className="turmas-sem-alunos">Nenhum aluno em risco informado para esta matéria.</p>
						)}
					</section>

					<section className="turmas-metricas" id="metricas-materia" aria-label={`Indicadores de ${nomeMateria}`}>
						<article className="turmas-metrica turmas-metrica-media">
							<span>Média da Turma</span>
							<div><strong>{metricas.mediaTurma ?? "--"}</strong><small>{metricas.variacaoMedia || ""}</small></div>
						</article>
						<article className="turmas-metrica turmas-metrica-aulas">
							<span>Aulas Ministradas</span>
							<div><strong>{metricas.aulasMinistradas ?? "--"}</strong><small>/ {metricas.aulasTotais ?? "--"} total</small></div>
						</article>
						<article className="turmas-metrica turmas-metrica-atividades">
							<span>Atividades Pendentes</span>
							<div><strong>{String(metricas.atividadesPendentes ?? "--").padStart(2, "0")}</strong><small>Corrigir</small></div>
						</article>
						<article className="turmas-metrica turmas-metrica-criticos">
							<span>Alunos Críticos</span>
							<div><strong>{String(metricas.alunosCriticos ?? alunosRisco.length).padStart(2, "0")}</strong><small>Ação req.</small></div>
						</article>
					</section>

					<label className="turmas-anotacao-campo" id="privacidade">
						<span>Nova anotação</span>
						<textarea id="nova-anotacao" placeholder={`Anotação sobre ${nomeMateria}...`} rows="3" />
					</label>
				</main>
			</div>
		</div>
	);
}