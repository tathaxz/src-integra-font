import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./FazerLogin.css";

export default function FazerLogin() {
  const navigate = useNavigate();
  const [mensagem, setMensagem] = useState("");

  function handleSubmit(event) {
    event.preventDefault();
    setMensagem("A autenticação será conectada ao backend.");
  }

  return (
    <main className="paginaLogin">
      <header className="cabecalhoLogin">
        <h1>INTEGRA</h1>
        <p>Portal do Aluno &amp; Docente</p>
      </header>

      <section className="conteudoLogin" aria-labelledby="tituloLogin">
        <div className="cardLogin">
          <div className="topoLogin">
            <span className="etiquetaLogin">Acesso à sua conta</span>
            <p>Entre com o e-mail e a senha cadastrados no Integra.</p>
          </div>

          <form className="formularioLogin" onSubmit={handleSubmit}>
            <label htmlFor="emailLogin">E-mail</label>
            <input
              id="emailLogin"
              name="email"
              type="email"
              placeholder="voce@exemplo.com"
              autoComplete="email"
              required
            />

            <label htmlFor="senhaLogin">Senha</label>
            <input
              id="senhaLogin"
              name="senha"
              type="password"
              placeholder="Digite sua senha"
              autoComplete="current-password"
              required
            />

            <button className="botaoEntrarLogin" type="submit">
              Entrar
            </button>
            <p className="mensagemLogin" role="status" aria-live="polite">
              {mensagem}
            </p>
          </form>

          <footer className="rodapeLogin">
            Ainda não tem uma conta?{" "}
            <button type="button" onClick={() => navigate("/cadastro")}>
              Cadastre-se
            </button>
          </footer>
        </div>
      </section>
    </main>
  );
}
