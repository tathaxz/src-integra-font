import "./PortalAluno.css";

const alunoExemplo = {
    nome: "Lucas Silva",
    curso: "Técnico em TI",
    desempenho: 85,
    horasAula: 12,
    frequencia: 78,
    mediasParciais: [
        { disciplina: "Lógica de Programação", nota: 9.5 },
        { disciplina: "Banco de Dados", nota: 8.2 },
        { disciplina: "Sistemas Operacionais", nota: 7.8 },
        { disciplina: "Redes de Computadores", nota: 8.9 },
    ],
};

export default function PortalAluno({ aluno = alunoExemplo }) {
    const frequenciaBaixa = aluno.frequencia <= 80;

    return (
        <div className="portal-aluno">
            <header className="portal-topbar">
                <h1>Aluno 360 - Espaço do Aluno</h1>
                <div className="portal-acoes">
                    <button type="button" aria-label="Notificações" title="Notificações">♧</button>
                    <button type="button" aria-label="Configurações" title="Configurações">⚙</button>
                    <div className="portal-avatar" aria-label={`Perfil de ${aluno.nome}`}>
                        {aluno.nome?.charAt(0) || "A"}
                    </div>
                </div>
            </header>

            <div className="portal-layout">
                <aside className="portal-sidebar">
                    <div className="portal-identificacao">
                        <div className="portal-icone-pessoa" aria-hidden="true">♙</div>
                        <div>
                            <strong>{aluno.nome}</strong>
                            <span>{aluno.curso}</span>
                        </div>
                    </div>
                    <nav aria-label="Navegação do aluno">
                        <a className="portal-link-ativo" href="#visao-geral" aria-current="page">
                            <span aria-hidden="true">▦</span> Visão Geral
                        </a>
                    </nav>
                </aside>

                <main className="portal-conteudo" id="visao-geral">
                    <section className="portal-boas-vindas" aria-label="Resumo do aluno">
                        <div className="portal-boas-vindas-texto">
                            <h2>Olá, {aluno.nome?.split(" ")[0]}!</h2>
                            <p>Veja como está o seu progresso esta semana. Continue focado para atingir suas metas!</p>
                        </div>
                        <div className="portal-indicadores">
                            <div className="portal-indicador">
                                <strong>{aluno.desempenho}%</strong>
                                <span>Desempenho</span>
                            </div>
                            <div className="portal-indicador">
                                <strong>{aluno.horasAula}</strong>
                                <span>Horas/aula</span>
                            </div>
                        </div>
                    </section>

                    <div className="portal-cartoes">
                        <section className="portal-card portal-medias">
                            <div className="portal-card-titulo">
                                <span className="portal-icone portal-icone-roxo" aria-hidden="true">☷</span>
                                <h2>Médias Parciais</h2>
                            </div>
                            <ul>
                                {aluno.mediasParciais.map((materia) => (
                                    <li key={materia.disciplina}>
                                        <span>{materia.disciplina}</span>
                                        <strong>{Number(materia.nota).toFixed(1)}</strong>
                                    </li>
                                ))}
                            </ul>
                        </section>

                        <section className={`portal-card portal-frequencia${frequenciaBaixa ? " portal-frequencia-alerta" : ""}`}>
                            <div className="portal-frequencia-cabecalho">
                                <span className="portal-icone portal-icone-vermelho" aria-hidden="true">▣</span>
                                {frequenciaBaixa && <span className="portal-etiqueta-alerta">Atenção</span>}
                            </div>
                            <h2>Sua Frequência: {aluno.frequencia}%</h2>
                            <p>
                                {frequenciaBaixa
                                    ? "Acompanhe suas faltas e procure a coordenação caso precise justificar ausências."
                                    : "Sua frequência está dentro do esperado. Continue assim!"}
                            </p>
                            <div
                                className="portal-barra-frequencia"
                                role="progressbar"
                                aria-label="Frequência"
                                aria-valuenow={aluno.frequencia}
                                aria-valuemin="0"
                                aria-valuemax="100"
                            >
                                <span style={{ width: `${aluno.frequencia}%` }} />
                            </div>
                        </section>
                    </div>

                    <aside className="portal-privacidade">
                        <span className="portal-icone-escudo" aria-hidden="true">⬡</span>
                        <div>
                            <h2>Seus Dados Estão Protegidos</h2>
                            <p>Operamos em total conformidade com a LGPD.<br />Suas notas e anotações são privadas e seguras.</p>
                            <div className="portal-links-privacidade">
                                <a href="#politica-de-privacidade">Política de Privacidade</a>
                                <span aria-hidden="true">•</span>
                                <a href="#termos-de-uso">Termos de uso</a>
                            </div>
                        </div>
                    </aside>
                </main>
            </div>
        </div>
    );
}   