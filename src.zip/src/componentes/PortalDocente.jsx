import "./PortalDocente.css";
import { useState } from "react";
import { Link } from "react-router-dom";
import imagemDestaque from "../assets/hero.png";
import NavbarDocente from "./NavbarDocente";

const disciplinas = [
    { nome: "Português", turma: "1º Ano A", status: "Ativa", alunos: 35, simbolo: "", cor: "lilas" },
    { nome: "Matemática", turma: "2º Ano B", status: "Urgente", progresso: 85, simbolo: "", cor: "roxo" },
    { nome: "Geografia", turma: "3º Ano C", status: "Planejamento", proximaAula: "Amanhã, 08:00", simbolo: "", cor: "amarelo" },
    { nome: "Biologia", turma: "1º Ano B", status: "Ativa", alunos: 29, simbolo: "", cor: "verde" },
    { nome: "Química", turma: "2º Ano A", status: "Ativa", alunos: 31, simbolo: "", cor: "azul" },
    { nome: "Física", turma: "3º Ano A", status: "Planejamento", proximaAula: "Quinta-feira, 14:00", simbolo: "", cor: "laranja" },
    { nome: "Inglês", turma: "1º Ano C", status: "Ativa", alunos: 27, simbolo: "", cor: "rosa" },
    { nome: "História", turma: "3º Ano B", status: "Ativa", alunos: 33, simbolo: "", cor: "turquesa" },
];

const meses = ["Jan", "Fev", "Mar", "Abr", "Mai"];
const frequenciaMensal = [76, 67, 83, 92, 72];

function slugMateria(nome) {
    return nome.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/\s+/g, "-");
}

export default function PortalDocente() {
    const [mostrarTodasDisciplinas, setMostrarTodasDisciplinas] = useState(false);

    return (
        <div className="portal-docente">
            <NavbarDocente ativa="dashboard" />

            <main className="docente-conteudo" id="inicio">
                <section className="docente-destaque" aria-labelledby="docente-titulo">
                    <div className="docente-chamada">
                        <span className="docente-etiqueta">Novo no portal</span>
                        <h1 id="docente-titulo">Acompanhamento<br />Pedagógico Centralizado</h1>
                    </div>
                    <div className="docente-imagem-wrap">
                        <img
                  src="https://www.dataplace.com.br/wp-content/uploads/2020/12/empresario.jpg"
                  alt="Docente"
                />
                        <div className="docente-nota-destaque">
                            <span className="docente-nota-icone" aria-hidden="true">✦</span>
                            <div>
                                <strong>Relatórios de IA Ativos</strong>
                                <span>Acompanhando 120 alunos agora</span>
                            </div>
                        </div>
                    </div>
                </section>

                <section className="docente-disciplinas" id="disciplinas" aria-labelledby="disciplinas-titulo">
                    <div className="docente-secao-cabecalho">
                        <div>
                            <h2 id="disciplinas-titulo">Suas Disciplinas Ativas</h2>
                            <p>Gerencie o conteúdo e a frequência de suas turmas atuais.</p>
                        </div>
                        <button
                            className="docente-ver-todas"
                            type="button"
                            onClick={() => setMostrarTodasDisciplinas((visiveis) => !visiveis)}
                            aria-expanded={mostrarTodasDisciplinas}
                        >
                            {mostrarTodasDisciplinas ? "Ver menos" : "Ver todas"}
                            <span aria-hidden="true">{mostrarTodasDisciplinas ? "↑" : "›"}</span>
                        </button>
                    </div>
                    <div className="docente-grade-disciplinas" aria-label="Disciplinas">
                        {disciplinas.slice(0, mostrarTodasDisciplinas ? disciplinas.length : 3).map((disciplina) => (
                            <Link className="docente-card-link" to={`/turmas/${slugMateria(disciplina.nome)}`} key={disciplina.nome}>
                            <article className="docente-card-disciplina">
                                <div className="docente-card-topo">
                                    <span className={`docente-simbolo docente-simbolo-${disciplina.cor}`} aria-hidden="true">{disciplina.simbolo}</span>
                                    <span className={`docente-status${disciplina.status === "Urgente" ? " docente-status-urgente" : ""}`}>{disciplina.status}</span>
                                </div>
                                <h3>{disciplina.nome}</h3>
                                <p className="docente-turma">{disciplina.turma}</p>
                                {disciplina.progresso ? (
                                    <div className="docente-progresso-wrap">
                                        <div className="docente-progresso" role="progressbar" aria-label={`Cronograma de ${disciplina.nome}`} aria-valuenow={disciplina.progresso} aria-valuemin="0" aria-valuemax="100">
                                            <span style={{ width: `${disciplina.progresso}%` }} />
                                        </div>
                                        <span>{disciplina.progresso}% do cronograma concluído</span>
                                    </div>
                                ) : disciplina.proximaAula ? (
                                    <p className="docente-proxima-aula"><span aria-hidden="true">▦</span> Próxima aula: {disciplina.proximaAula}</p>
                                ) : (
                                    <div className="docente-alunos">
                                        <span className="docente-grupo-alunos" aria-hidden="true"><i /><i /><i /><small>+32</small></span>
                                        <span>{disciplina.alunos} Alunos</span>
                                    </div>
                                )}
                            </article>
                            </Link>
                        ))}
                    </div>
                </section>

                <section className="docente-metricas" id="metricas" aria-labelledby="metricas-titulo">
                    <div className="docente-metricas-resumo">
                        <h2 id="metricas-titulo">Métricas Gerais da Escola</h2>
                        <p>Acompanhamento em tempo real da frequência e engajamento médio de todas as unidades Senai Centro.</p>
                        <div className="docente-indicador-escola">
                            <span>Frequência Média</span>
                            <strong>94.2%</strong>
                        </div>
                        <div className="docente-indicador-escola">
                            <span>Engajamento Digital</span>
                            <strong>78.5%</strong>
                        </div>
                    </div>
                    <div className="docente-grafico" role="img" aria-label="Frequência mensal: janeiro 76%, fevereiro 67%, março 83%, abril 92%, maio 72%">
                        {meses.map((mes, indice) => (
                            <div className={`docente-coluna${mes === "Abr" ? " docente-coluna-ativa" : ""}`} key={mes}>
                                <span className="docente-barra" style={{ height: `${frequenciaMensal[indice]}%` }} />
                                <span className="docente-mes">{mes}</span>
                            </div>
                        ))}
                    </div>
                </section>
            </main>

            
        </div>
    );
}